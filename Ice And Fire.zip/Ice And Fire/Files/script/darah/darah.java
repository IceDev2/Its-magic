package JAVARuntime;

//import skrip lain
import JAVARuntime.musuh;

// Useful imports
import java.util.*;
import java.text.*;
import java.net.*;
import java.math.*;
import java.io.*;
import java.nio.*;

/**
 * @Author 
*/
public class darah extends Component { 
//buat kurang darah
public float darah,dk,dt;
public UIProgressBar bar;

    /// Run only once
    @Override
    public void start() {
       
    }

    /// Repeat every frame
    @Override
    public void repeat() {
        bar.setValue(darah);
        mati();
    }

    /// Repeat every frame when component or object is disabled
    @Override
    public void disabledRepeat() {
        
    }
    
    
    //kurang
    public void kurang(){
        darah -= Math.bySecond(dk);
        
        }
        //tambah
    public void tambah(){
        darah += Math.bySecond(dt);
    }
    
    //kondisi mati
    public void mati(){
        if (darah <= 0.0f){
            GameController.quit();
        }
    }
}
