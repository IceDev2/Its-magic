package JAVARuntime;

// Useful imports
import java.util.*;
import java.text.*;
import java.net.*;
import java.math.*;
import java.io.*;
import java.nio.*;

/**
 * @Author 
*/
public class movement extends Component { 
public String joystickkey;
public int ms;
private Vector2 joystick;
//buat slide
public float camX,camY;
public float angle;
public SpatialObject camera;


    /// Run only once
    @Override
     public void start() {
        
    }

    /// Repeat every frame
    @Override
    public void repeat() {
        gerak ();
    }

    /// Repeat every frame when component or object is disabled
    @Override
    public void disabledRepeat() {
        
    }


public void gerak(){
    joystick = Input.getAxis(joystickkey).getValue();
    myObject.getTransform().moveInSeconds(joystick.getX()*ms , 0 , joystick.getY()*ms);
    
}
public void muter(){
    
    
}} 

