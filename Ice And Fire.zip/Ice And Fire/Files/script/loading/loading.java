package JAVARuntime;

// Useful imports
import java.util.*;
import java.text.*;
import java.net.*;
import java.math.*;
import java.io.*;
import java.nio.*;

/**
 * @Author 
*/
public class loading extends Component { 
//value bar
public float value,vt = 5;
public UIProgressBar bar;
public PFile world;
    /// Run only once
    @Override
    public void start() {
        
    }

    /// Repeat every frame
    @Override
    public void repeat() {
        sistem();
        value += Math.bySecond(vt);
        bar.setValue(value);
        
        if(value >=100){
            WorldController.loadWorld(world);
        }
        
    }

    /// Repeat every frame when component or object is disabled
    @Override
    public void disabledRepeat() {
        
    }
    
    //sistem
   public void sistem(){
       if(value >= 50){
           vt = 10;
       }
   }
}
