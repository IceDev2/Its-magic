package JAVARuntime;

// Useful imports
import java.util.*;
import java.text.*;
import java.net.*;
import java.math.*;
import java.io.*;
import java.nio.*;

/**
 * @Author 
*/
public class mainmenu extends Component { 
public SUIButton play,cre,ex;
public PFile worldP,worldC;
    /// Run only once
    @Override
    public void start() {
        
    }

    /// Repeat every frame
    @Override
    public void repeat() {
        if(play.isPressed()){
            WorldController.loadWorld(worldP);
        }else if(cre.isPressed()){
            WorldController.loadWorld(worldC);
         }else if(ex.isPressed()){
             GameController.quit();
         }
    }

    /// Repeat every frame when component or object is disabled
    @Override
    public void disabledRepeat() {
        
    }
}
