package JAVARuntime;

// Useful imports
import java.util.*;
import java.text.*;
import java.net.*;
import java.math.*;
import java.io.*;
import java.nio.*;

/**
 * @Author 
*/
public class spawner extends Component { 
public float waktu,wt,wk;
public PFile musuh;

    /// Run only once
    @Override
    public void start() {
        
    }

    /// Repeat every frame
    @Override
    public void repeat() {
        Spawn();
    }

    /// Repeat every frame when component or object is disabled
    @Override
    public void disabledRepeat() {
        
    }
   
   //buat spawn 
    public void Spawn(){
        waktu += Math.bySecond(wt);
        if(waktu >= 3.0f){
            //spawn object
            myObject.instantiate(musuh);
            waktu -= wk;
        }
        }
    }
