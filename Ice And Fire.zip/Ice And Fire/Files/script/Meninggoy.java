package JAVARuntime;

// Useful imports
import java.util.*;
import java.text.*;
import java.net.*;
import java.math.*;
import java.io.*;
import java.nio.*;

/**
 * @Author 
*/
public class Meninggoy extends Component { 
public Rigidbody rb;
    /// Run only once
    @Override
    public void start() {
        rb = myObject.getPhysics().getPhysicsEntity();
    }

    /// Repeat every frame
    @Override
    public void repeat() {
        if(rb.colliderWithName("player")){
            GameController.quit();
        }
    }

    /// Repeat every frame when component or object is disabled
    @Override
    public void disabledRepeat() {
        
    }
}
