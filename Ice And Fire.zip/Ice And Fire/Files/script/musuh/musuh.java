package JAVARuntime;

//import script
import JAVARuntime.darah.*;

// Useful imports
import java.util.*;
import java.text.*;
import java.net.*;
import java.math.*;
import java.io.*;
import java.nio.*;

/**
 * @Author 
*/
public class musuh extends Component { 
//player
public SpatialObject player;
//buat movement
public float kecepatan = 8;

private Rigidbody rb;
public String PName;

//waktu sebelum mati
public float time,tt,tk;

public darah cDarah = new darah();

private Vector3 v3;
    /// Run only once
    @Override
    public void start() {
        rb = myObject.getPhysics().getPhysicsEntity();
        
    }

    /// Repeat every frame
    @Override
    public void repeat() {
        time += Math.bySecond(tt);
         movement();
         nyerang();
         v3 = new Vector3(Random.range(-25.0f,25.0f),1.4f,Random.range(-25.0f,25.0f));
         waktu();
    }

    /// Repeat every frame when component or object is disabled
    @Override
    public void disabledRepeat() { 
        
    }
    
    //buat movement
    public void movement() {
        //buat liat ke player
        myObject.getTransform().lookTo(player);
        //gerak
        myObject.getTransform().moveInSeconds(0,0, kecepatan);
    }
    
        //nyerang
        public void nyerang(){
            if(rb.colliderWithName(PName)){
                cDarah.kurang();
                waktu();
            }else{
                cDarah.tambah();
            }
        }
        
        

       
        //delay sebelum mati
        public void waktu(){
            if(time >= tk){
                myObject.getTransform().teleportTo(v3);
                time -= tk;
            }
        }


        
    }
