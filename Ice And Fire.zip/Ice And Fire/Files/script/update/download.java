package JAVARuntime;

// Useful imports
import java.util.*;
import java.text.*;
import java.net.*;
import java.math.*;
import java.io.*;
import java.nio.*;

/**
 * @Author 
*/
public class download extends Component { 
public String url;
public String fileName;
private String path;

    /// Run only once
    @Override
    public void start() {
    path = Directories.internal()+fileName;
    download(url,path);
    }
    
    public void download(String link, String file){
    try{
    InputStream in = new URL(link).openStream();
    BufferedInputStream bs = new  BufferedInputStream(in);
    FileOutputStream fs = new FileOutputStream(file);
    byte[ ] data = new byte[1024];
    int count;
    while((count = bs.read(data,0,1024)) != -1 ){
    fs.write(data,0,count);
    }
    fs.close();
    bs.close();
    }catch(Exception e){
    
    }
    }

    /// Repeat every frame
    @Override
    public void repeat() {
      
    }

    /// Repeat every frame when component or object is disabled9
    @Override
    public void disabledRepeat() {
        
    }
}
