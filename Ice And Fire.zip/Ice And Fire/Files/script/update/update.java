package JAVARuntime;

// Useful imports
import java.util.*;
import java.text.*;
import java.net.*;
import java.math.*;
import java.io.*;
import java.nio.*;

/**
 * @Author 
*/
public class update extends Component { 
public String currentVersion,url;
public SUIController ler,ai;
    /// Run only once
    @Override
    public void start() {
        
       
        }

    /// Repeat every frame
    @Override
    public void repeat() {
        String tm = getVersion(url);
       if(tm.contains(currentVersion)){
            //ntar munculin sui
            ler.setEnabled(false);
            ai.setEnabled(true);
        }else {
            ler.setEnabled(true);
            ai.setEnabled(false);
        }
        
    }

    public String getVersion(String ur){
        String tm = ur;
        try{
            URL url = new URL(ur);
            BufferedReader reader = new BufferedReader(new InputStreamReader(url.openStream()));
            StringBuilder build = new StringBuilder();
            int tm1 = 0;
            char[] cs = new char[1024];
            while((tm1 =reader.read(cs)) > 0){
                build.append(cs,0,tm1);
            }
            return build.toString();
            }catch(Exception e){
                return "offline";
            }
    }




    /// Repeat every frame when component or object is disabled
    @Override
    public void disabledRepeat() {
        
    }
}
