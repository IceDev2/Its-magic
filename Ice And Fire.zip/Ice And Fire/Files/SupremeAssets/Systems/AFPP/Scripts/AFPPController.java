package JAVARuntime;

// Useful imports
import java.util.*;

/**
 * @Author 
*/
public class AFPPController extends Component { 
    
    @Order(idx={-12})
    public String jumpKey = "jump";
    @Order(idx={-11})
    public String runKey = "run";
    @Order(idx={-10})
    public String joystickAxis = "joystick";
    @Order(idx={-9})
    public String slideAxis = "slide";
    
    @Order(idx={-8})
    public float walkSpeed = 2; 
    @Order(idx={-7})
    public float runSpeed = 4; 
    
    @Order(idx={-6})
    public float moveLerpSpeed = 2;

    @Order(idx={-5})
    public float jumpSpeed = 10;
    
    @Order(idx={-4})
    public float horizontalSensitivity = 10f;
    @Order(idx={-3})
    public float verticalSensitivity = 6f;
    
    @Order(idx={-2})
    public float cameraMinAngle = -89;
    @Order(idx={-1})
    public float cameraMaxAngle = 89;
        
    private Characterbody cb;
    private AFPPCamera ac; 
    private Vector2 slideVec = new Vector2();
    private float appliedSpeed = 0;
   
 
    /// Run only once
    @Override
    public void start() {
        

    }

    /// Repeat every frame
    @Override
    public void repeat() {       
        Key jump = Input.getKey(jumpKey);
        Key run = Input.getKey(runKey);
        Axis joy = Input.getAxis(joystickAxis);
        Axis slide = Input.getAxis(slideAxis);
        slideVec.setX(-slide.getValue().getX());
        slideVec.setY(-slide.getValue().getY());
        
        float speed = walkSpeed;
        if(run.isPressed()){
            speed = runSpeed;
        }        
        appliedSpeed = Math.lerpInSeconds(appliedSpeed, speed, moveLerpSpeed);
        getCB().setForwardSpeed(appliedSpeed * joy.getValue().getY());
        getCB().setSideSpeed(appliedSpeed * -joy.getValue().getX());
        getCB().setJumpSpeed(jumpSpeed);
        
        if(jump.isDown() || jump.isPressed()){ 
            if(getCB().canJump()){
                getCB().jump();
            }            
        }        
 
        /// horizontal slide
        myObject.getTransform().rotateInSeconds(0, slideVec.getX() * horizontalSensitivity * 360 * 0.0041f, 0);
        
        /// vertical slide
        getAC().minAngle = cameraMinAngle;
        getAC().maxAngle = cameraMaxAngle;
        getAC().currentAngle += slideVec.getY() * verticalSensitivity * 90 * 0.0008f;
        getAC().set();
    }
       
    private AFPPCamera getAC(){ 
        if(ac == null){
            ac = findComponentInObjectWithChildren(myObject, AFPPCamera.class);
        }        
        return ac;
    }    
    
    private Characterbody getCB(){
        if(cb == null){
            if(myObject.getPhysics().getPhysicsEntity() instanceof Characterbody){                              
               cb = (Characterbody) myObject.getPhysics().getPhysicsEntity();
            } else { 
               print(this.getClass().getSimpleName() + " needs to be attached on a Characterbody object");
            }            
        }        
        return cb;
    }    
    
    public static <T extends Component> T findComponentInObjectWithChildren(SpatialObject parent, Class compType){ 
         Component cComp = parent.findComponent(compType); 
         if(cComp != null){ 
              return (T) cComp;           
         } 
         return findComponentInChildren(parent, compType);
    } 

    public static <T extends Component> T findComponentInChildren(SpatialObject parent, Class compType){ 
        int cc = parent.getChildCount(); 
        for(int x = 0; x < cc; x++){ 
              SpatialObject child = parent.getChildAt(x); 
              Component cComp = child.findComponent(compType);
              if(cComp != null){ 
                   return (T) cComp;                    
              }
              cComp = findComponentInChildren(child, compType); 
              if(cComp != null){ 
                  return (T) cComp;              
              }               
        }
        return null;
        
         } }
        


