package JAVARuntime;

// Useful imports
import java.util.*;
import java.text.*;
import java.net.*;
import java.math.*;
import java.io.*;
import java.nio.*;

/**
 * @Author 
*/
public class AFPPCamera extends Component { 

    
    public float currentAngle;
    @Hide
    public float minAngle = -80;
    @Hide
    public float maxAngle = 80;
    
    private Vector3 dir = new Vector3();

    /// Run only once
    @Override
    public void start() {
        
    }

    /// Repeat every frame
    @Override
    public void repeat() {
        
    }

    public void set(){
        currentAngle = Math.clamp(minAngle, currentAngle, maxAngle);
        float cos = Math.cos(currentAngle);
        float sin = Math.sin(currentAngle);
        dir.set(0, sin, cos);
        myObject.getTransform().getRotation().localLookTo(dir);
    }    
}
