package JAVARuntime;

// Useful imports
import java.util.*;
import java.text.*;
import java.net.*;
import java.math.*;
import java.io.*;
import java.nio.*;

/**
 * @Author 
*/
public class AFPPVerticalSlide extends Component { 

    /// Script Properties Configurations (Optional)
    public String getComponentMenu(){ return "AFPP"; }
    public Color getComponentColor(){ return new Color(231, 76, 60); }

    public float sens = 5;
    public float minAngle = 0;
    public float maxAngle = 80;
    private float angle = 0;
   
    
    public String axisName = "slide";
    private Axis axis = null;

    /// Run only once
    public void start() {  
    }

    /// Repeat every frame
    public void repeat() {
    	  angle += getAxis().getValue().getY() * sens * Math.bySecond();
    	  angle = Math.clamp(minAngle, angle, maxAngle);
 
    	
    	  float cos = Math.cos(-angle);
    	  float sin = Math.sin(-angle);
        myObject.getTransform().getRotation().selfLookTo(new Vector3(0, sin, cos));
    }
    
    private Axis getAxis(){
    	 if(axis == null){
    		  axis = Input.getAxis(axisName);  
    	 }
    	 return axis;
    }
}
