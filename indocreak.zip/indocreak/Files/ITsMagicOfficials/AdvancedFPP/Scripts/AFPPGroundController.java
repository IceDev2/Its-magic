package JAVARuntime;

// Useful imports
import java.util.*;
import java.text.*;
import java.net.*;
import java.math.*;
import java.io.*;
import java.nio.*;

/**
 * @Author 
*/
public class AFPPGroundController extends Component { 
	
	  /// Script Properties Configurations (Optional)
    public String getComponentMenu(){ return "AFPP"; }
    public Color getComponentColor(){ return new Color(52, 152, 219); }
  
    private Rigidbody rb;
	  public float groundedNormalBias = 0.6f;
	  public boolean grounded;
    
    private boolean nextValue = false;
    private float timer = 0;
    
    public float ungroundTimer = 0.25f;
    
    private Laser laser;
    public Vector3 laserPosition = new Vector3(0,-0.1f,0);
    public Vector3 laserDirection = new Vector3(0,-1,0);
    public float laserLength = 0.5f;
    /// Run only once
    public void start() {
        laser = new Laser();
    }

    /// Repeat every frame
    public void repeat() {
    	  if(nextValue == false && grounded == true){
    	     timer -= Math.bySecond(1);
    	     
    	     if(timer <= 0){
    	        grounded = nextValue;	
    	        timer = ungroundTimer;
    	     }	
    	  } else {
    	  	 grounded = nextValue;
    	  	 timer = ungroundTimer;
    	  }
    	  
    	  myObject.callFunction("setGrounded", new Boolean(grounded));
    }
    
    public void posPhysics(){
       calculateGrounded();	
    }
    
    private void calculateGrounded(){
    	  nextValue = false;
    	  
    	  getRB();
    	
        ArrayList colList = rb.getCollisionList();
        if(colList.size() >= 0){
           for(int x = 0; x < colList.size(); x ++){
        	    Collision col = (Collision) colList.get(x);
        	    
        	    Vector3 globalNormal = new Vector3();
        	    globalNormal.setY(1);
        	    
        	    float dot = col.getNormal().dot(globalNormal);
        	    
        	    if(dot >= groundedNormalBias){
        	       nextValue = true;	
        	       break;
        	    }
           }
        }
        
        if(!nextValue){
        	 //// If the grounding calculation using rigidbody collisions
        	 //// returned FALSE, its time to check using laser
        	 //// then is the laser does not collide, the player
        	 //// is not grounded
        	 LaserHit hit = laser.trace(myObject.getTransform().getPosition().sum(laserPosition), laserDirection, laserLength);	
    	     nextValue = (hit != null);
        }
    }

    private Rigidbody getRB(){
        if(rb == null){
          	if(myObject.getPhysics().getPhysicsEntity().getTittle().equals("Rigidbody")){
               rb = (Rigidbody) myObject.getPhysics().getPhysicsEntity();
            } else {
            	 Console.log("AFPP Controller needs to be attached on a rigidbody object");
            }
        }
        
        return rb;	
    }
    
    public boolean isGrounded(){
    	  return grounded;
    }
}
