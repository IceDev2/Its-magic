package JAVARuntime;

// Useful imports
import java.util.*;
import java.text.*;
import java.net.*;
import java.math.*;
import java.io.*;
import java.nio.*;

/**
 * @Author 
*/
public class AFPP extends Component { 
	
    /// Script Properties Configurations (Optional)
    public String getComponentMenu(){ return "AFPP"; }
    public Color getComponentColor(){ return new Color(52, 152, 219); }
    
    public float walkSpeed = 2;
    public float runSpeed = 4;
    
    public float jumpForce = 5;
    
    public float horizontalSlideSens = 5;
    
    public String moveJoystickName = "joystick";
    private Axis moveAxis = null;
    
    public String horizontalSlideName = "slide";
    private Axis haxis = null;
    
    public String jumpKeyName = "jump";
    private Key jumpKey;
    
    public String runKeyName = "run";
    private Key runKey;
    
    public float walkingFriction = 0;
    public float idleFriction = 1;
    
    private Rigidbody rb;
    private boolean running = false;
    public boolean grounded = false;
    
    /// Run only once
    public void start() {
    }

    /// Repeat every frame
    public void repeat() {
        move();
        rotate();
        jump();
    } 
    
    private void jump(){
    	  getJumpKey();
    	  if(grounded && (jumpKey.isDown() || jumpKey.isPressed()) ){
    	     getRB().getVelocity().setY(jumpForce);
    	  }
    }
    
    private void move(){
        Vector3 forward = myObject.getTransform().forward();
        Vector3 right = myObject.getTransform().right();
        
        running = getRunKey().isPressed();
        
        if(!running){
           forward = forward.mul( getMoveSlide().getY() * walkSpeed );
           right = right.mul( getMoveSlide().getX() * walkSpeed );
        } else {
        	 forward = forward.mul( getMoveSlide().getY() * runSpeed );
           right = right.mul( getMoveSlide().getX() * runSpeed );
        }
        getRBVelocity().setX( forward.getX() + right.getX() );
        getRBVelocity().setZ( forward.getZ() + right.getZ() );
        
        if(getMoveSlide().length() > 0){
        	  getRB().setFriction(walkingFriction);
        } else {
        	  getRB().setFriction(idleFriction);
        }
    }
    
    private void rotate(){
    	  float rotSpeed = getHSlide().getX() * horizontalSlideSens;
    	  
    	  /// Call CharacterEntity script rotate function
       	myObject.callFunction("rotateInSeconds", new Float(-rotSpeed));
    }
    
    private Key getJumpKey(){
    	  if(jumpKey == null){
    	    	jumpKey = Input.registerKey(jumpKeyName);
    	  }
    	  return jumpKey;
    }
    private Key getRunKey(){
    	  if(runKey == null){
    	    	runKey = Input.registerKey(runKeyName);
    	  }
    	  return runKey;
    }

    private Vector2 getMoveSlide(){
       if(moveAxis == null){
          moveAxis = Input.getAxis(moveJoystickName);	
       }	
       return moveAxis.getValue();
    }
    
    private Vector2 getHSlide(){
       if(haxis == null){
          haxis = Input.getAxis(horizontalSlideName);	
       }	
       return haxis.getValue();
    }
    
    private Vector3 getRBVelocity(){
       return getRB().getVelocity();	
    }
    
    private Rigidbody getRB(){
        if(rb == null){
          	if(myObject.getPhysics().getPhysicsEntity().getTittle().equals("Rigidbody")){
               rb = (Rigidbody) myObject.getPhysics().getPhysicsEntity();
            } else {
            	 Console.log("AFPP Controller needs to be attached on a rigidbody object");
            }
        }
        
        return rb;	
    }
    
    /// CALLED BY AFPPGroundController Script
    public void setGrounded(boolean value){
        this.grounded = value;	
    }
}
