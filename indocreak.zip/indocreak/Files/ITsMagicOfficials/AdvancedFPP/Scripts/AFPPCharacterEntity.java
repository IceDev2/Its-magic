package JAVARuntime;

// Useful imports
import java.util.*;
import java.text.*;
import java.net.*;
import java.math.*;
import java.io.*;
import java.nio.*;

/**
 * @Author ITsMagic Software
 * This scripts gives the object a Character physics
 * Access this script over component search (FindComponent)
 * And instead of rotating the object by its transform
 * You rotate using this scripts
 */
public class AFPPCharacterEntity extends Component { 

    /// Script Properties Configurations (Optional)
    public String getComponentMenu(){ return "AFPP"; }
    public Color getComponentColor(){ return new Color(52, 152, 219); }

    public boolean enabled = true;
    public float rotationY;
    private Vector3 pivot = new Vector3();
    private float cachedEditorRotY = 99999;

    /// Run only once
    public void start() {
        if(pivot == null){ pivot = new Vector3(); }
    }

    /**
    	* Utilitary functions, use this functions the same way you use transform functions
    	*/
  	public void rotateInSeconds(float rot){
  		 rotationY += Math.bySecond(rot);
  	}
  	public void rotate(float rot){
  		 rotationY += rot;
    }
    public void lookTo(Vector3 position){
    	 if(!enabled){ return; }
    	 
     	 myObject.getTransform().lookTo(position);
    	 rotationY = myObject.getTransform().getRotation().getY();
    	 look();
    }
    public void setEnabled(boolean value){
       enabled = value;
    }    
    public boolean isEnabled(){
    	 return enabled;
    }
    
    
    /**
    	* Physics functions are called by rigidbody, when attached to object
    	*/
    public void prePhysics(){
    	 look();
    }
    public void posPhysics(){
       look();	
    }
    
    private void look(){
    	if(!enabled){ return; }
    	
       pivot.setX(Math.sin(rotationY));
       pivot.setY(0);
       pivot.setZ(Math.cos(rotationY));
       
       myObject.getTransform().getRotation().selfLookTo(pivot);	
    }
    
    /**
    	* StoppedRepeat function only works on Editor, when the game is paused/stoped
    	* the purpose of this function here, is to allow user to rotate the character while
    	* in editor mode.
    	*/
    public void stoppedRepeat(){
    	 if(!enabled){ return; }
       if(pivot == null){ pivot = new Vector3(); }
       
       if(cachedEditorRotY == rotationY){
       	  float curRot = 0;
       	  curRot = myObject.getTransform().getRotation().getY();
       	   
       	  if(cachedEditorRotY != curRot){
       	  	 rotationY = curRot;
       	  	 cachedEditorRotY = curRot;
       	  	 look();
       	  }  
       } else {
          cachedEditorRotY = rotationY;
          look();	
       }	
    }
}
