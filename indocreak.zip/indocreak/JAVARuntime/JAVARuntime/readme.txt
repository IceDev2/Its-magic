ITsMagic Java package
